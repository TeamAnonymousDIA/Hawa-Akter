<?php  include_once'template/header.php';?>
  <?php

include_once '../dbCon.php';
$conn = connect();
$sql = "SELECT count(ideas.id) AS 'BITIdeas' FROM `ideas`,users WHERE ideas.students_id=users.id AND department_id=1;";
$IdeaOfBIT = $conn->query($sql);
$BIT=mysqli_fetch_assoc($IdeaOfBIT);
$b=$BIT['BITIdeas'];

//Total ideas
$totalIDeas = "SELECT count(ideas.id) AS 'TotalIdea' FROM `ideas`;";
$TotalIdeas = $conn->query($totalIDeas);
$Total=mysqli_fetch_assoc($TotalIdeas);
$T=$Total['TotalIdea'];

$percentageOfBIT=(($b/$T)*100);
$BITTotal=number_format((float)$percentageOfBIT, 1, '.', '');


//2nd department
$sql = "SELECT count(ideas.id) AS 'CSEIdeas' FROM `ideas`,users WHERE ideas.students_id=users.id AND department_id=2;";
$IdeaOfCSE = $conn->query($sql);
$CSE=mysqli_fetch_assoc($IdeaOfCSE);
$C=$CSE['CSEIdeas'];

$percentageOfCSE=(($C/$T)*100);
$CSETotal=number_format((float)$percentageOfCSE, 1, '.', '');


//3rd department
$sql = "SELECT count(ideas.id) AS 'ITIdeas' FROM `ideas`,users WHERE ideas.students_id=users.id AND department_id=3;";
$IdeaOfIT = $conn->query($sql);
$IT=mysqli_fetch_assoc($IdeaOfIT);
$I=$IT['ITIdeas'];

$percentageOfIT=(($I/$T)*100);
$ITTotal=number_format((float)$percentageOfIT, 1, '.', '');

//4th department
$sql = "SELECT count(ideas.id) AS 'EEEIdeas' FROM `ideas`,users WHERE ideas.students_id=users.id AND department_id=4;";
$IdeaOfEEE = $conn->query($sql);
$EEE=mysqli_fetch_assoc($IdeaOfEEE);
$E=$EEE['EEEIdeas'];

$percentageOfEEE=(($E/$T)*100);
$EEETotal=number_format((float)$percentageOfEEE, 1, '.', '');

//number of contributors of BIT department

$sql="SELECT ideas.students_id  FROM `ideas`,users WHERE ideas.students_id=users.id AND users.department_id=1 GROUP BY ideas.students_id";
$result=$conn->query($sql);
$BitContributors=mysqli_num_rows($result);



//number of contributors of CSE department

$sql="SELECT ideas.students_id  FROM `ideas`,users WHERE ideas.students_id=users.id AND users.department_id=2 GROUP BY ideas.students_id";
$CSEContributor=$conn->query($sql);
$ContributorsCSE=mysqli_num_rows($CSEContributor);

//number of contributors of IT department

$sql="SELECT ideas.students_id  FROM `ideas`,users WHERE ideas.students_id=users.id AND users.department_id=3 GROUP BY ideas.students_id";
$ITContributor=$conn->query($sql);
$ContributorsIT=mysqli_num_rows($ITContributor);


//number of contributors of EEE department

$sql="SELECT ideas.students_id  FROM `ideas`,users WHERE ideas.students_id=users.id AND users.department_id=4 GROUP BY ideas.students_id";
$EEEContributor=$conn->query($sql);
$ContributorsEEE=mysqli_num_rows($EEEContributor);

//Total contributors

$totalContributors=$BitContributors+$ContributorsCSE+$ContributorsIT+$ContributorsEEE;


//Idea Without Comment
$sql="SELECT id FROM ideas WHERE id NOT IN (SELECT idea_id FROM comments) AND publication_status=1;";
$IdeaNocomment=$conn->query($sql);
$Nocomment=mysqli_num_rows($IdeaNocomment);

//anonymous Post
$sql="select id from ideas where anonymous_post=1";
$anonymousPost=$conn->query($sql);
$anonymousPost=mysqli_num_rows($anonymousPost);
//anonymous Comment
$sql="select id from comments where anonymous_comment=1";
$anonymouscomment=$conn->query($sql);
$anonymouscomment=mysqli_num_rows($anonymouscomment);

?>


  <body class="nav-md">
    <div class="container body">
      <div class="main_container">
        <div class="col-md-3 left_col">
          <div class="left_col scroll-view">
            <div class="navbar nav_title" style="border: 0;">
               <a href="#" class="site_title"><i class="fa fa-paw"></i> <span><?php echo $_SESSION['username']; ?></span></a>
            </div>

            <div class="clearfix"></div>

            <!-- menu profile quick info -->
			<?php  include_once'template/admin-profile.php';?>

			<!-- /menu profile quick info -->

            <br />

            <!-- sidebar menu -->
          <?php include_once'template/side-bar.php';?>
        <!-- top navigation -->
		<?php include_once'template/navbar.php';?>
<!-- /top navigation -->

        <!-- page content -->
        <div class="right_col" role="main">
          <!-- top tiles -->
          <div class="row tile_count">
            <div class="col-md-2 col-sm-4 col-xs-6 tile_stats_count">
              <span class="count_top"><i class="fa fa-user"></i> BIT Contributors</span>
              <div class="count" style="text-align:center;"><?=$BitContributors?></div>
              <span class="count_bottom"><i class="green">4% </i> From last Week</span>
            </div>
            <div class="col-md-2 col-sm-4 col-xs-6 tile_stats_count">
              <span class="count_top"><i class="fa fa-user"></i> CSE Contributors</span>
              <div class="count" style="text-align:center;"><?=$ContributorsCSE?></div>
              <span class="count_bottom"><i class="green"><i class="fa fa-sort-asc"></i>3% </i> From last Week</span>
            </div>
            <div class="col-md-2 col-sm-4 col-xs-6 tile_stats_count">
              <span class="count_top"><i class="fa fa-user"></i> IT Contributors</span>
              <div class="count green" style="text-align:center;"><?=$ContributorsIT?></div>
              <span class="count_bottom"><i class="green"><i class="fa fa-sort-asc"></i>34% </i> From last Week</span>
            </div>
            <div class="col-md-2 col-sm-4 col-xs-6 tile_stats_count">
              <span class="count_top"><i class="fa fa-user"></i> EEE Contributors</span>
              <div class="count" style="text-align:center;"><?=$ContributorsEEE?></div>
              <span class="count_bottom"><i class="red"><i class="fa fa-sort-desc"></i>12% </i> From last Week</span>
            </div>
            <div class="col-md-2 col-sm-4 col-xs-6 tile_stats_count">
              <span class="count_top"><i class="fa fa-user"></i> Total Collections</span>
              <div class="count" style="text-align:center;"><?=$totalContributors?></div>
              <span class="count_bottom"><i class="green"><i class="fa fa-sort-asc"></i>34% </i> From last Week</span>
            </div>
              </div>
          <!-- /top tiles -->

          <div class="row">
             <br />

          <div class="row">

<!--NUmber of ideas-->
            <div class="col-md-4 col-sm-4 col-xs-12">
              <div class="x_panel tile fixed_height_320">
                <div class="x_title">
                  <h2>Number of ideas</h2>
                  <ul class="nav navbar-right panel_toolbox">
                    <li><a class="collapse-link"><i class="fa fa-chevron-up"></i></a>
                    </li>
                    <li class="dropdown">
                      <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-expanded="false"><i class="fa fa-wrench"></i></a>
                      <ul class="dropdown-menu" role="menu">
                        <li><a href="#">Settings 1</a>
                        </li>
                        <li><a href="#">Settings 2</a>
                        </li>
                      </ul>
                    </li>
                    <li><a class="close-link"><i class="fa fa-close"></i></a>
                    </li>
                  </ul>
                  <div class="clearfix"></div>
                </div>
				<?php
									$select = "SELECT count(*) as total from ideas ";
								$result = $conn->query($select);
								$rws = $result->fetch_assoc();
									
									$total = $rws['total'];
								
									?>
				
                <div class="x_content">
                  <h4>Each Deparment ideas</h4>
				  
				  				<?php 
				$sel = "SELECT * , COUNT(i.id) AS total FROM ideas AS i, users AS u, department AS d WHERE d.id =u.department_id AND u.id = i.students_id GROUP BY d.id";
				$rs= $conn->query($sel) or die($conn->error);
				while($row= $rs->fetch_assoc()){
				?>
                  <div class="widget_summary">
                    <div class="w_left w_25">
                      <span><?php echo $row['department_name'] ?></span>
                    </div>
                    <div class="w_center w_55">
                      <div class="progress">
                        <div class="progress-bar bg-green" role="progressbar" aria-valuenow="60" aria-valuemin="0" aria-valuemax="100" style="width: <?php echo (($row['total'])/$total) * 100?>%;">
                          <span class="sr-only"><?php echo (($row['total'])/$total) * 100?>% Complete</span>
                        </div>
						
                      </div>
                    </div>
                    <div class="w_right w_20">
                      <span><?php echo $row['total'] ?></span>
                    </div>
                    <div class="clearfix"></div>
                  </div>

				<?php } ?>
                
                </div>
              </div>
            </div>
<!-- Department percentage-->
            <div class="col-md-4 col-sm-4 col-xs-12">
		
              <div class="x_panel tile fixed_height_320 overflow_hidden">
                <div class="x_title">
                  <h2>Percentage of ideas</h2>
                  <ul class="nav navbar-right panel_toolbox">
                    <li><a class="collapse-link"><i class="fa fa-chevron-up"></i></a>
                    </li>
                    <li class="dropdown">
                      <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-expanded="false"><i class="fa fa-wrench"></i></a>
                      <ul class="dropdown-menu" role="menu">
                        <li><a href="#">Settings 1</a>
                        </li>
                        <li><a href="#">Settings 2</a>
                        </li>
                      </ul>
                    </li>
                    <li><a class="close-link"><i class="fa fa-close"></i></a>
                    </li>
                  </ul>
                  <div class="clearfix"></div>
                </div>
                <div class="x_content">
                  <table class="" style="width:100%">
                    <tr>

                      <th>
                        <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12" style="margin:0px;padding:0px;">
                          <p class="">Deparment View</p>
                        </div>
                        
                      </th>
                    </tr>
                    <tr>

                      <td>
                        <table class="tile_info">
                          <tr>
						  				<?php 
				$sel = "SELECT * , COUNT(i.id) AS total FROM ideas AS i, users AS u, department AS d WHERE d.id =u.department_id AND u.id = i.students_id GROUP BY d.id";
				$rs= $conn->query($sel) or die($conn->error);
				While($row= $rs->fetch_assoc()){
				$value = ($row['total']/$total*100)
				
				
				?>
						  
                            <td>
                              <p><i class="fa fa-square blue"></i><?php echo $row['department_name'] ?></p>
                            </td>
                            <td><?php echo (round($value,2))?>%</td>
                          </tr>

<?php } ?>

                         
                        </table>
                      </td>
                    </tr>
                  </table>
                </div>
              </div>
            </div>

<!--Ideas without comment-->
            <div class="col-md-4 col-sm-4 col-xs-12">
              <div class="x_panel tile fixed_height_320">
                <div class="x_title">
                  <h2>Specific Reports</h2>
                  <ul class="nav navbar-right panel_toolbox">
                    <li><a class="collapse-link"><i class="fa fa-chevron-up"></i></a>
                    </li>
                    <li class="dropdown">
                      <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-expanded="false"><i class="fa fa-wrench"></i></a>
                      <ul class="dropdown-menu" role="menu">
                        <li><a href="#">Settings 1</a>
                        </li>
                        <li><a href="#">Settings 2</a>
                        </li>
                      </ul>
                    </li>
                    <li><a class="close-link"><i class="fa fa-close"></i></a>
                    </li>
                  </ul>
                  <div class="clearfix"></div>
                </div>
                <div class="x_content">
                  <div class="dashboard-widget-content">
                   <h4>Ideas Without Comment :<span><b><?=$Nocomment?></b></span></h4>
                   <h4>Anonymous Post :<span><b><?=$anonymousPost?></b></span></h4>
                   <h4>Anonymous Comment :<span><b><?=$anonymouscomment?></b></span></h4>

                </div>
                </div>
              </div>
            </div>
			

            <div class="col-md-8 col-sm-8 col-xs-12">
             
                <div class="x_title">
                  <h2>Percentage of Ideas in Pie Chart</h2>
                  <ul class="nav navbar-right panel_toolbox">
                    <li><a class="collapse-link"><i class="fa fa-chevron-up"></i></a>
                    </li>
                    <li class="dropdown">
                      <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-expanded="false"><i class="fa fa-wrench"></i></a>
                      <ul class="dropdown-menu" role="menu">
                        <li><a href="#">Settings 1</a>
                        </li>
                        <li><a href="#">Settings 2</a>
                        </li>
                      </ul>
                    </li>
                    <li><a class="close-link"><i class="fa fa-close"></i></a>
                    </li>
                  </ul>
                  <div class="clearfix"></div>
                </div>
	
				
                <div class="x_content">
                  <h4>Each Deparment ideas</h4>
				  					

                  <div class="widget_summary">
				<div id="piechart"></div>

                    <div class="clearfix"></div>
					<script type="text/javascript" src="https://www.gstatic.com/charts/loader.js"></script>

<script type="text/javascript">
// Load google charts
google.charts.load('current', {'packages':['corechart']});
google.charts.setOnLoadCallback(drawChart);

// Draw the chart and set the chart values
function drawChart() {


  var data = google.visualization.arrayToDataTable([

  ['Dept.', 'No. of Ideas'],
  	  <?php 
				$sel = "SELECT * , COUNT(i.id) AS total FROM ideas AS i, users AS u, department AS d WHERE d.id =u.department_id AND u.id = i.students_id GROUP BY d.id";
				$rs= $conn->query($sel) or die($conn->error);
				while ($row= $rs->fetch_assoc()){
					$total = $row['total'];

					?>
  ['<?php echo $row['department_name'] ?>', <?php echo $total ?> ],
 
				<?php } ?>
]);


  // Optional; add a title and set the width and height of the chart
  var options = {'title':'', 'width':500, 'height':400};

  // Display the chart inside the <div> element with id="piechart"
  var chart = new google.visualization.PieChart(document.getElementById('piechart'));
  chart.draw(data, options);
}

</script>
                  </div>

				
                
                </div>

				


              </div>

 


          </div>
        </div>
		    <script src="js/plugins/morris/raphael.min.js"></script>
    <script src="js/plugins/morris/morris.min.js"></script>
    <script src="js/plugins/morris/morris-data.js"></script>

    <!-- Flot Charts JavaScript -->
    <!--[if lte IE 8]><script src="js/excanvas.min.js"></script><![endif]-->
    <script src="js/plugins/flot/jquery.flot.js"></script>
    <script src="js/plugins/flot/jquery.flot.tooltip.min.js"></script>
    <script src="js/plugins/flot/jquery.flot.resize.js"></script>
    <script src="js/plugins/flot/jquery.flot.pie.js"></script>
    <script src="js/plugins/flot/flot-data.js"></script>
        <!-- /page content -->

        <!-- footer content -->
      <?php include_once'template/footer.php';?>
	   <!-- foot-scripts content -->
      <?php include_once'template/foot-scripts.php';?>